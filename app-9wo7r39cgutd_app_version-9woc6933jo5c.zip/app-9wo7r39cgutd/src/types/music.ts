// Music generation types

export type Mood = 'happy' | 'sad' | 'calm' | 'energetic';
export type Genre = 'pop' | 'rock' | 'jazz' | 'electronic';
export type Style = 'simple' | 'complex';

export interface MusicParameters {
  mood: Mood;
  genre: Genre;
  tempo: number;
  style: Style;
}

export interface Note {
  pitch: number;
  duration: number;
  velocity: number;
  time: number;
}

export interface Track {
  notes: Note[];
  instrument: string;
}

export interface GeneratedMusic {
  tracks: Track[];
  parameters: MusicParameters;
  duration: number;
}

export const MOOD_OPTIONS: { value: Mood; label: string; emoji: string }[] = [
  { value: 'happy', label: 'Happy', emoji: '😊' },
  { value: 'sad', label: 'Sad', emoji: '😢' },
  { value: 'calm', label: 'Calm', emoji: '😌' },
  { value: 'energetic', label: 'Energetic', emoji: '⚡' },
];

export const GENRE_OPTIONS: { value: Genre; label: string; emoji: string }[] = [
  { value: 'pop', label: 'Pop', emoji: '🎵' },
  { value: 'rock', label: 'Rock', emoji: '🎸' },
  { value: 'jazz', label: 'Jazz', emoji: '🎷' },
  { value: 'electronic', label: 'Electronic', emoji: '🎹' },
];

export const STYLE_OPTIONS: { value: Style; label: string; emoji: string }[] = [
  { value: 'simple', label: 'Simple', emoji: '🌱' },
  { value: 'complex', label: 'Complex', emoji: '🌟' },
];
