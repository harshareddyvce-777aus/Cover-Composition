import HomePage from './pages/HomePage';
import ResultPage from './pages/ResultPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <HomePage />
  },
  {
    name: 'Result',
    path: '/result',
    element: <ResultPage />
  }
];

export default routes;
