import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AudioPlayer } from '@/components/music/AudioPlayer';
import { ParameterCard } from '@/components/music/ParameterCard';
import { ArrowLeft } from 'lucide-react';
import type { GeneratedMusic } from '@/types/music';
import { MOOD_OPTIONS, GENRE_OPTIONS, STYLE_OPTIONS } from '@/types/music';
import { generateMusic } from '@/utils/musicGenerator';
import { toast } from 'sonner';

export default function ResultPage() {
  const navigate = useNavigate();
  const [music, setMusic] = useState<GeneratedMusic | null>(null);

  useEffect(() => {
    const storedMusic = sessionStorage.getItem('generatedMusic');
    if (storedMusic) {
      try {
        setMusic(JSON.parse(storedMusic));
      } catch (error) {
        console.error('Failed to parse stored music:', error);
        toast.error('Failed to load music data');
        navigate('/');
      }
    } else {
      toast.error('No music data found');
      navigate('/');
    }
  }, [navigate]);

  const handleRegenerate = () => {
    if (!music) return;

    toast.info('Regenerating music...');
    
    setTimeout(() => {
      try {
        const newMusic = generateMusic(music.parameters);
        setMusic(newMusic);
        sessionStorage.setItem('generatedMusic', JSON.stringify(newMusic));
        toast.success('Music regenerated successfully!');
      } catch (error) {
        console.error('Regeneration error:', error);
        toast.error('Failed to regenerate music');
      }
    }, 500);
  };

  const handleBackToHome = () => {
    navigate('/');
  };

  if (!music) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  const moodOption = MOOD_OPTIONS.find(opt => opt.value === music.parameters.mood);
  const genreOption = GENRE_OPTIONS.find(opt => opt.value === music.parameters.genre);
  const styleOption = STYLE_OPTIONS.find(opt => opt.value === music.parameters.style);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex items-center gap-4 animate-fade-in">
            <Button
              variant="outline"
              size="icon"
              onClick={handleBackToHome}
              className="rounded-full"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold gradient-text">
                Your Generated Track
              </h1>
              <p className="text-sm md:text-base text-muted-foreground mt-1">
                Listen, download, or regenerate your music
              </p>
            </div>
          </div>

          {/* Audio Player */}
          <div className="animate-slide-in">
            <AudioPlayer music={music} onRegenerate={handleRegenerate} />
          </div>

          {/* Parameters Display */}
          <div className="space-y-4 animate-fade-in">
            <h2 className="text-xl font-semibold text-foreground">
              Track Parameters
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {moodOption && (
                <ParameterCard
                  label="Mood"
                  value={moodOption.label}
                  emoji={moodOption.emoji}
                />
              )}
              {genreOption && (
                <ParameterCard
                  label="Genre"
                  value={genreOption.label}
                  emoji={genreOption.emoji}
                />
              )}
              <ParameterCard
                label="Tempo"
                value={`${music.parameters.tempo} BPM`}
                emoji="⏱️"
              />
              {styleOption && (
                <ParameterCard
                  label="Style"
                  value={styleOption.label}
                  emoji={styleOption.emoji}
                />
              )}
            </div>
          </div>

          {/* Track Info */}
          <div className="bg-card/50 rounded-lg p-6 cloud-shadow space-y-3">
            <h3 className="text-lg font-semibold text-foreground">Track Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Tracks</p>
                <p className="font-medium text-foreground">{music.tracks.length} (Melody, Bass, Drums)</p>
              </div>
              <div>
                <p className="text-muted-foreground">Total Notes</p>
                <p className="font-medium text-foreground">
                  {music.tracks.reduce((sum, track) => sum + track.notes.length, 0)}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Algorithm</p>
                <p className="font-medium text-foreground">Markov Chain</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 text-center text-sm text-muted-foreground">
        <p>© 2026 CoverComposer. All rights reserved.</p>
      </footer>
    </div>
  );
}
