import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MusicForm } from '@/components/music/MusicForm';
import type { MusicParameters } from '@/types/music';
import { generateMusic } from '@/utils/musicGenerator';
import { toast } from 'sonner';

export default function HomePage() {
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = (parameters: MusicParameters) => {
    setIsGenerating(true);
    toast.info('Generating your music...');

    // Simulate generation delay for better UX
    setTimeout(() => {
      try {
        const music = generateMusic(parameters);
        
        // Store in sessionStorage to pass to result page
        sessionStorage.setItem('generatedMusic', JSON.stringify(music));
        
        toast.success('Music generated successfully!');
        navigate('/result');
      } catch (error) {
        console.error('Generation error:', error);
        toast.error('Failed to generate music. Please try again.');
      } finally {
        setIsGenerating(false);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4 animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-bold gradient-text">
              CoverComposer
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-xl mx-auto">
              AI-Powered Music Track Generator
            </p>
            <p className="text-sm md:text-base text-muted-foreground">
              Create unique instrumental tracks with advanced Markov Chain algorithms
            </p>
          </div>

          {/* Form */}
          <div className="animate-slide-in">
            <MusicForm onSubmit={handleGenerate} isGenerating={isGenerating} />
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-8">
            <div className="text-center p-4 rounded-lg bg-card/50 cloud-shadow">
              <div className="text-3xl mb-2">🎵</div>
              <h3 className="font-semibold text-sm mb-1">AI-Powered</h3>
              <p className="text-xs text-muted-foreground">
                Markov Chain melody generation
              </p>
            </div>
            <div className="text-center p-4 rounded-lg bg-card/50 cloud-shadow">
              <div className="text-3xl mb-2">🎹</div>
              <h3 className="font-semibold text-sm mb-1">Multi-Track</h3>
              <p className="text-xs text-muted-foreground">
                Melody, bass, and drums
              </p>
            </div>
            <div className="text-center p-4 rounded-lg bg-card/50 cloud-shadow">
              <div className="text-3xl mb-2">💾</div>
              <h3 className="font-semibold text-sm mb-1">Export</h3>
              <p className="text-xs text-muted-foreground">
                Download as WAV format
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 text-center text-sm text-muted-foreground">
        <p>© 2026 CoverComposer. All rights reserved.</p>
      </footer>
    </div>
  );
}
