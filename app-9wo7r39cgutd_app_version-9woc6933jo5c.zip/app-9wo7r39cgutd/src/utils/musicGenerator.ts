// Music generation using Markov Chains and algorithmic composition

import type { MusicParameters, Note, Track, GeneratedMusic, Mood, Genre } from '@/types/music';

// Scale definitions based on mood
const SCALES: Record<Mood, number[]> = {
  happy: [0, 2, 4, 5, 7, 9, 11], // Major scale
  sad: [0, 2, 3, 5, 7, 8, 10], // Natural minor scale
  calm: [0, 2, 4, 7, 9], // Pentatonic major
  energetic: [0, 3, 5, 7, 10], // Pentatonic minor
};

// Markov Chain transition probabilities
const TRANSITION_MATRIX: Record<number, number[]> = {
  0: [0, 2, 4, 7], // Root can go to root, 2nd, 3rd, 5th
  2: [0, 4, 7, 9], // 2nd can go to root, 3rd, 5th, 6th
  4: [2, 5, 7, 11], // 3rd can go to 2nd, 4th, 5th, 7th
  5: [4, 7, 9], // 4th can go to 3rd, 5th, 6th
  7: [0, 5, 9, 11], // 5th can go to root, 4th, 6th, 7th
  9: [7, 11, 0, 2], // 6th can go to 5th, 7th, root, 2nd
  11: [0, 9, 7], // 7th can go to root, 6th, 5th
};

// Instrument mapping for genres
const GENRE_INSTRUMENTS: Record<Genre, string> = {
  pop: 'piano',
  rock: 'guitar',
  jazz: 'bass',
  electronic: 'synth',
};

class MarkovChainGenerator {
  private scale: number[];
  private baseOctave: number;

  constructor(scale: number[], baseOctave = 4) {
    this.scale = scale;
    this.baseOctave = baseOctave;
  }

  // Generate next note based on current note using Markov Chain
  private getNextNote(currentNote: number): number {
    const scaleIndex = currentNote % 12;
    const possibleTransitions = TRANSITION_MATRIX[scaleIndex] || [0, 2, 4, 7];
    
    // Filter transitions to only include notes in the current scale
    const validTransitions = possibleTransitions.filter(note => 
      this.scale.includes(note)
    );
    
    if (validTransitions.length === 0) {
      return this.scale[0] + this.baseOctave * 12 + 60;
    }
    
    const nextScaleNote = validTransitions[Math.floor(Math.random() * validTransitions.length)];
    const octaveVariation = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1 octave
    
    return nextScaleNote + (this.baseOctave + octaveVariation) * 12 + 60;
  }

  // Generate a melody sequence
  generateMelody(length: number, tempo: number, style: 'simple' | 'complex'): Note[] {
    const notes: Note[] = [];
    let currentTime = 0;
    
    // Start with root note
    let currentNote = this.scale[0] + this.baseOctave * 12 + 60;
    
    const beatDuration = 60 / tempo; // Duration of one beat in seconds
    
    for (let i = 0; i < length; i++) {
      // Determine note duration based on style
      let duration: number;
      if (style === 'simple') {
        duration = beatDuration * (Math.random() > 0.7 ? 2 : 1);
      } else {
        const durations = [0.25, 0.5, 0.75, 1, 1.5, 2];
        duration = beatDuration * durations[Math.floor(Math.random() * durations.length)];
      }
      
      // Determine velocity (volume)
      const velocity = style === 'simple' 
        ? 0.6 + Math.random() * 0.2 
        : 0.5 + Math.random() * 0.4;
      
      notes.push({
        pitch: currentNote,
        duration,
        velocity,
        time: currentTime,
      });
      
      currentTime += duration;
      currentNote = this.getNextNote(currentNote);
    }
    
    return notes;
  }
}

// Generate bass line (simplified version of melody, one octave lower)
function generateBassLine(melodyNotes: Note[], tempo: number): Note[] {
  const bassNotes: Note[] = [];
  const beatDuration = 60 / tempo;
  let currentTime = 0;
  
  // Create bass notes on strong beats
  for (let i = 0; i < melodyNotes.length; i += 2) {
    const melodyNote = melodyNotes[i];
    bassNotes.push({
      pitch: melodyNote.pitch - 12, // One octave lower
      duration: beatDuration * 2,
      velocity: 0.7,
      time: currentTime,
    });
    currentTime += beatDuration * 2;
  }
  
  return bassNotes;
}

// Generate drum pattern
function generateDrums(duration: number, tempo: number, style: 'simple' | 'complex'): Note[] {
  const drums: Note[] = [];
  const beatDuration = 60 / tempo;
  let currentTime = 0;
  
  const kickPitch = 36; // Bass drum
  const snarePitch = 38; // Snare drum
  const hihatPitch = 42; // Closed hi-hat
  
  while (currentTime < duration) {
    // Kick on beats 1 and 3
    if (Math.floor(currentTime / beatDuration) % 4 === 0 || 
        Math.floor(currentTime / beatDuration) % 4 === 2) {
      drums.push({
        pitch: kickPitch,
        duration: beatDuration * 0.5,
        velocity: 0.8,
        time: currentTime,
      });
    }
    
    // Snare on beats 2 and 4
    if (Math.floor(currentTime / beatDuration) % 4 === 1 || 
        Math.floor(currentTime / beatDuration) % 4 === 3) {
      drums.push({
        pitch: snarePitch,
        duration: beatDuration * 0.5,
        velocity: 0.7,
        time: currentTime,
      });
    }
    
    // Hi-hat on every beat (complex style only)
    if (style === 'complex') {
      drums.push({
        pitch: hihatPitch,
        duration: beatDuration * 0.25,
        velocity: 0.5,
        time: currentTime,
      });
    }
    
    currentTime += beatDuration;
  }
  
  return drums;
}

// Main music generation function
export function generateMusic(parameters: MusicParameters): GeneratedMusic {
  const { mood, genre, tempo, style } = parameters;
  
  const scale = SCALES[mood];
  const generator = new MarkovChainGenerator(scale, 4);
  
  // Generate melody (16-32 notes depending on style)
  const melodyLength = style === 'simple' ? 16 : 32;
  const melodyNotes = generator.generateMelody(melodyLength, tempo, style);
  
  // Calculate total duration
  const duration = melodyNotes[melodyNotes.length - 1].time + 
                   melodyNotes[melodyNotes.length - 1].duration;
  
  // Generate bass line
  const bassNotes = generateBassLine(melodyNotes, tempo);
  
  // Generate drums
  const drumNotes = generateDrums(duration, tempo, style);
  
  const tracks: Track[] = [
    {
      notes: melodyNotes,
      instrument: GENRE_INSTRUMENTS[genre],
    },
    {
      notes: bassNotes,
      instrument: 'bass',
    },
    {
      notes: drumNotes,
      instrument: 'drums',
    },
  ];
  
  return {
    tracks,
    parameters,
    duration,
  };
}
