// Audio synthesis using Web Audio API

import type { GeneratedMusic, Track, Note } from '@/types/music';

export class AudioSynthesizer {
  private audioContext: AudioContext;
  private masterGain: GainNode;
  private isPlaying: boolean = false;
  private scheduledSources: AudioBufferSourceNode[] = [];

  constructor() {
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.masterGain = this.audioContext.createGain();
    this.masterGain.connect(this.audioContext.destination);
    this.masterGain.gain.value = 0.3; // Master volume
  }

  // Create oscillator for a specific instrument
  private createInstrumentOscillator(
    instrument: string,
    frequency: number,
    startTime: number,
    duration: number,
    velocity: number
  ): void {
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    const filterNode = this.audioContext.createBiquadFilter();

    // Configure oscillator based on instrument
    switch (instrument) {
      case 'piano':
        oscillator.type = 'triangle';
        filterNode.type = 'lowpass';
        filterNode.frequency.value = 2000;
        break;
      case 'guitar':
        oscillator.type = 'sawtooth';
        filterNode.type = 'bandpass';
        filterNode.frequency.value = 1000;
        filterNode.Q.value = 1;
        break;
      case 'bass':
        oscillator.type = 'sine';
        filterNode.type = 'lowpass';
        filterNode.frequency.value = 500;
        break;
      case 'synth':
        oscillator.type = 'square';
        filterNode.type = 'highpass';
        filterNode.frequency.value = 200;
        break;
      default:
        oscillator.type = 'sine';
    }

    oscillator.frequency.value = frequency;

    // ADSR envelope
    const attackTime = 0.01;
    const decayTime = 0.1;
    const sustainLevel = velocity * 0.7;
    const releaseTime = 0.2;

    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.gain.linearRampToValueAtTime(velocity, startTime + attackTime);
    gainNode.gain.linearRampToValueAtTime(sustainLevel, startTime + attackTime + decayTime);
    gainNode.gain.setValueAtTime(sustainLevel, startTime + duration - releaseTime);
    gainNode.gain.linearRampToValueAtTime(0, startTime + duration);

    // Connect nodes
    oscillator.connect(filterNode);
    filterNode.connect(gainNode);
    gainNode.connect(this.masterGain);

    // Schedule playback
    oscillator.start(startTime);
    oscillator.stop(startTime + duration);

    this.scheduledSources.push(oscillator as any);
  }

  // Create noise for drums
  private createDrumSound(
    pitch: number,
    startTime: number,
    duration: number,
    velocity: number
  ): void {
    if (pitch === 36) {
      // Kick drum - low frequency sine wave
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(150, startTime);
      oscillator.frequency.exponentialRampToValueAtTime(0.01, startTime + duration);

      gainNode.gain.setValueAtTime(velocity, startTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

      oscillator.connect(gainNode);
      gainNode.connect(this.masterGain);

      oscillator.start(startTime);
      oscillator.stop(startTime + duration);

      this.scheduledSources.push(oscillator as any);
    } else if (pitch === 38) {
      // Snare drum - noise burst
      const bufferSize = this.audioContext.sampleRate * duration;
      const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
      const data = buffer.getChannelData(0);

      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.1));
      }

      const source = this.audioContext.createBufferSource();
      const gainNode = this.audioContext.createGain();
      const filterNode = this.audioContext.createBiquadFilter();

      filterNode.type = 'highpass';
      filterNode.frequency.value = 1000;

      source.buffer = buffer;
      gainNode.gain.value = velocity * 0.5;

      source.connect(filterNode);
      filterNode.connect(gainNode);
      gainNode.connect(this.masterGain);

      source.start(startTime);

      this.scheduledSources.push(source);
    } else if (pitch === 42) {
      // Hi-hat - high frequency noise
      const bufferSize = this.audioContext.sampleRate * duration;
      const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
      const data = buffer.getChannelData(0);

      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.05));
      }

      const source = this.audioContext.createBufferSource();
      const gainNode = this.audioContext.createGain();
      const filterNode = this.audioContext.createBiquadFilter();

      filterNode.type = 'highpass';
      filterNode.frequency.value = 5000;

      source.buffer = buffer;
      gainNode.gain.value = velocity * 0.3;

      source.connect(filterNode);
      filterNode.connect(gainNode);
      gainNode.connect(this.masterGain);

      source.start(startTime);

      this.scheduledSources.push(source);
    }
  }

  // Convert MIDI note number to frequency
  private midiToFrequency(midiNote: number): number {
    return 440 * Math.pow(2, (midiNote - 69) / 12);
  }

  // Play a single track
  private playTrack(track: Track, startTime: number): void {
    track.notes.forEach((note: Note) => {
      const noteStartTime = startTime + note.time;

      if (track.instrument === 'drums') {
        this.createDrumSound(note.pitch, noteStartTime, note.duration, note.velocity);
      } else {
        const frequency = this.midiToFrequency(note.pitch);
        this.createInstrumentOscillator(
          track.instrument,
          frequency,
          noteStartTime,
          note.duration,
          note.velocity
        );
      }
    });
  }

  // Play the entire generated music
  play(music: GeneratedMusic): void {
    if (this.isPlaying) {
      this.stop();
    }

    this.isPlaying = true;
    const startTime = this.audioContext.currentTime + 0.1;

    music.tracks.forEach((track) => {
      this.playTrack(track, startTime);
    });

    // Auto-stop after duration
    setTimeout(() => {
      this.isPlaying = false;
    }, (music.duration + 0.5) * 1000);
  }

  // Stop playback
  stop(): void {
    this.scheduledSources.forEach((source) => {
      try {
        source.stop();
      } catch (e) {
        // Source may already be stopped
      }
    });
    this.scheduledSources = [];
    this.isPlaying = false;
  }

  // Check if currently playing
  getIsPlaying(): boolean {
    return this.isPlaying;
  }

  // Export to WAV (simplified - creates a renderable audio buffer)
  async exportToWAV(music: GeneratedMusic): Promise<Blob> {
    // Create offline context for rendering
    const offlineContext = new OfflineAudioContext(
      2,
      this.audioContext.sampleRate * (music.duration + 1),
      this.audioContext.sampleRate
    );

    const offlineMasterGain = offlineContext.createGain();
    offlineMasterGain.connect(offlineContext.destination);
    offlineMasterGain.gain.value = 0.3;

    // Render all tracks
    music.tracks.forEach((track) => {
      track.notes.forEach((note) => {
        if (track.instrument === 'drums') {
          // Simplified drum rendering for offline context
          const oscillator = offlineContext.createOscillator();
          const gainNode = offlineContext.createGain();
          oscillator.frequency.value = note.pitch === 36 ? 100 : note.pitch === 38 ? 200 : 400;
          gainNode.gain.setValueAtTime(note.velocity * 0.5, note.time);
          gainNode.gain.exponentialRampToValueAtTime(0.01, note.time + note.duration);
          oscillator.connect(gainNode);
          gainNode.connect(offlineMasterGain);
          oscillator.start(note.time);
          oscillator.stop(note.time + note.duration);
        } else {
          const oscillator = offlineContext.createOscillator();
          const gainNode = offlineContext.createGain();
          oscillator.frequency.value = this.midiToFrequency(note.pitch);
          oscillator.type = track.instrument === 'piano' ? 'triangle' : 
                           track.instrument === 'guitar' ? 'sawtooth' :
                           track.instrument === 'synth' ? 'square' : 'sine';
          
          gainNode.gain.setValueAtTime(0, note.time);
          gainNode.gain.linearRampToValueAtTime(note.velocity, note.time + 0.01);
          gainNode.gain.setValueAtTime(note.velocity * 0.7, note.time + note.duration - 0.1);
          gainNode.gain.linearRampToValueAtTime(0, note.time + note.duration);
          
          oscillator.connect(gainNode);
          gainNode.connect(offlineMasterGain);
          oscillator.start(note.time);
          oscillator.stop(note.time + note.duration);
        }
      });
    });

    const renderedBuffer = await offlineContext.startRendering();

    // Convert AudioBuffer to WAV
    return this.audioBufferToWav(renderedBuffer);
  }

  // Convert AudioBuffer to WAV blob
  private audioBufferToWav(buffer: AudioBuffer): Blob {
    const length = buffer.length * buffer.numberOfChannels * 2;
    const arrayBuffer = new ArrayBuffer(44 + length);
    const view = new DataView(arrayBuffer);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, buffer.numberOfChannels, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * buffer.numberOfChannels * 2, true);
    view.setUint16(32, buffer.numberOfChannels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length, true);

    // Write audio data
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
        const sample = Math.max(-1, Math.min(1, buffer.getChannelData(channel)[i]));
        view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
        offset += 2;
      }
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  // Clean up resources
  dispose(): void {
    this.stop();
    this.audioContext.close();
  }
}
