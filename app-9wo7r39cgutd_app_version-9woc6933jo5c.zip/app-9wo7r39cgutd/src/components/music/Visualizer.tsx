import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

interface VisualizerProps {
  isPlaying: boolean;
  barCount?: number;
}

export const Visualizer: React.FC<VisualizerProps> = ({ isPlaying, barCount = 32 }) => {
  const barsRef = useRef<number[]>(Array(barCount).fill(0.2));
  const animationRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (isPlaying) {
      const animate = () => {
        barsRef.current = barsRef.current.map(() => 
          0.2 + Math.random() * 0.8
        );
        animationRef.current = requestAnimationFrame(animate);
      };
      animate();
    } else {
      if (animationRef.current !== undefined) {
        cancelAnimationFrame(animationRef.current);
      }
      barsRef.current = Array(barCount).fill(0.2);
    }

    return () => {
      if (animationRef.current !== undefined) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, barCount]);

  return (
    <div className="flex items-end justify-center gap-1 h-32 px-4">
      {Array.from({ length: barCount }).map((_, index) => (
        <motion.div
          key={index}
          className="flex-1 bg-gradient-to-t from-primary to-secondary rounded-full min-w-[2px]"
          animate={{
            height: isPlaying 
              ? `${20 + Math.random() * 80}%` 
              : '20%',
          }}
          transition={{
            duration: 0.15,
            repeat: isPlaying ? Number.POSITIVE_INFINITY : 0,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  );
};
