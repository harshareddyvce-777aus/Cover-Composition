import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Play, Pause, Download, RotateCcw } from 'lucide-react';
import { Visualizer } from './Visualizer';
import { AudioSynthesizer } from '@/utils/audioSynthesizer';
import type { GeneratedMusic } from '@/types/music';
import { toast } from 'sonner';

interface AudioPlayerProps {
  music: GeneratedMusic;
  onRegenerate: () => void;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ music, onRegenerate }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const synthesizerRef = useRef<AudioSynthesizer | null>(null);

  useEffect(() => {
    synthesizerRef.current = new AudioSynthesizer();

    return () => {
      if (synthesizerRef.current) {
        synthesizerRef.current.dispose();
      }
    };
  }, []);

  const handlePlayPause = () => {
    if (!synthesizerRef.current) return;

    if (isPlaying) {
      synthesizerRef.current.stop();
      setIsPlaying(false);
    } else {
      synthesizerRef.current.play(music);
      setIsPlaying(true);

      // Auto-stop after duration
      setTimeout(() => {
        setIsPlaying(false);
      }, (music.duration + 0.5) * 1000);
    }
  };

  const handleDownload = async () => {
    if (!synthesizerRef.current) return;

    setIsDownloading(true);
    toast.info('Generating audio file...');

    try {
      const blob = await synthesizerRef.current.exportToWAV(music);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `covercomposer_${Date.now()}.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success('Audio file downloaded successfully!');
    } catch (error) {
      console.error('Download error:', error);
      toast.error('Failed to download audio file');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Card className="cloud-shadow border-border/50">
      <CardContent className="p-6 space-y-6">
        <Visualizer isPlaying={isPlaying} />

        <div className="flex items-center justify-center gap-3">
          <Button
            size="lg"
            onClick={handlePlayPause}
            className="rounded-full w-16 h-16"
          >
            {isPlaying ? (
              <Pause className="h-6 w-6" />
            ) : (
              <Play className="h-6 w-6 ml-1" />
            )}
          </Button>

          <Button
            size="lg"
            variant="outline"
            onClick={handleDownload}
            disabled={isDownloading}
            className="rounded-full"
          >
            <Download className="h-5 w-5 mr-2" />
            {isDownloading ? 'Generating...' : 'Download'}
          </Button>

          <Button
            size="lg"
            variant="outline"
            onClick={onRegenerate}
            className="rounded-full"
          >
            <RotateCcw className="h-5 w-5 mr-2" />
            Regenerate
          </Button>
        </div>

        <div className="text-center text-sm text-muted-foreground">
          <p>Duration: {music.duration.toFixed(1)}s</p>
          <p className="mt-1">Tempo: {music.parameters.tempo} BPM</p>
        </div>
      </CardContent>
    </Card>
  );
};
