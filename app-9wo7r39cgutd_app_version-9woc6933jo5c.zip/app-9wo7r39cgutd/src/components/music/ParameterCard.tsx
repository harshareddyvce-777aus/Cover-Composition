import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ParameterCardProps {
  label: string;
  value: string;
  emoji: string;
  className?: string;
}

export const ParameterCard: React.FC<ParameterCardProps> = ({
  label,
  value,
  emoji,
  className,
}) => {
  return (
    <Card className={cn('cloud-shadow border-border/50', className)}>
      <CardContent className="p-4 flex items-center gap-3">
        <div className="text-3xl">{emoji}</div>
        <div className="flex-1">
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-base font-medium text-foreground capitalize">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
};
