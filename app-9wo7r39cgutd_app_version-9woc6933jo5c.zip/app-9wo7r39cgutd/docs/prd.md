# CoverComposer: AI-Powered Music Track Generator Requirements Document

## 1. Application Overview

### 1.1 Application Name
CoverComposer

### 1.2 Application Description
CoverComposer is an AI-powered web application designed to generate custom instrumental tracks based on user-defined parameters such as mood, genre, tempo, and style. The platform offers users a seamless, interactive experience to explore generative music technology, leveraging MIDI generation libraries and audio synthesis engines.

## 2. Core Features

### 2.1 Music Generation
- Users can create unique musical compositions by selecting:
  - Mood (Happy, Sad, Calm, Energetic)
  - Genre (Pop, Rock, Jazz, Electronic)
  - Tempo (customizable BPM)
  - Style (Simple or Complex)
- AI-powered melody generation using Markov Chains
- Multi-track MIDI generation including melody, bass, and drums
- Dynamic audio synthesis converting MIDI to WAV format

### 2.2 Audio Playback & Download
- Real-time audio player with animated visualizer bars
- Download generated tracks in WAV format
- Regenerate tracks with different parameters

### 2.3 User Interface
- Dark-themed, modern design with responsive layout
- Interactive form for parameter selection
- Result page displaying user selections and generated audio
- Animated visual elements and smooth transitions

## 3. Technical Implementation

### 3.1 Backend Architecture
- FastAPI framework for web API and backend logic
- Mood-to-scale mapping system
- Markov Chain-based melody generation algorithm
- Multi-instrument support with genre-based General MIDI instrument mapping
- MIDI to WAV conversion using FluidSynth and SoundFont technology
- Automatic file generation with timestamped naming

### 3.2 Frontend Components
- Jinja2 templated HTML pages (index.html, result.html)
- Custom CSS with dark theme and animated elements
- Responsive form design with emoji indicators
- Audio player with visual feedback

### 3.3 File Structure
- main.py: Core backend script with FastAPI routes
- requirements.txt: Python package dependencies
- soundfont.sf2: General MIDI-compatible SoundFont file
- static/ folder: CSS files and generated audio output
- templates/ folder: HTML templates for rendering

### 3.4 Core Routes
- GET /: Homepage with input form
- POST /: Track generation endpoint
- /download/{filename}: File download endpoint

## 4. Music Generation Logic

### 4.1 Melody Generation
- Markov Chain algorithm for probabilistic note transitions
- Mood-based scale selection (major, minor, pentatonic, etc.)
- Rhythm and dynamics variation based on style selection

### 4.2 Multi-Track Composition
- Track 0: Melody using selected genre instrument
- Track 1: Bass line (octave lower version of melody)
- Track 2: Drums (kick and snare percussion on MIDI channel 9)

### 4.3 Instrument Mapping
- Pop: Acoustic Grand Piano
- Rock: Overdriven Guitar
- Jazz: Acoustic Bass
- Electronic: Synth Lead

## 5. User Scenarios

### 5.1 Random Sampling
Users can create random music samples by selecting tempo, with the system randomizing notes and keys to provide a unique track.

### 5.2 Genre-Based Sampling
Users can choose from 4 genres (Pop, Rock, Jazz, Electronic) to generate beats using drums, synthesizers, and guitars.

### 5.3 Mood/Style-Based Sampling
Users can select from 4 moods and choose between simple or complex beat patterns to generate customized sample tracks.

## 6. Output Management

### 6.1 File Generation
- Automatic creation of uniquely timestamped MIDI (.mid) and WAV (.wav) files
- Files stored in static/output/ directory
- Secure filename handling for downloads

### 6.2 Audio Format
- Primary output: WAV format
- MIDI files also available for advanced users

## 7. Deployment

### 7.1 Local Deployment
- Installation command: pip install -r requirements.txt
- Launch command: uvicorn main:app --reload
- Default URL: http://127.0.0.1:8000

## 8. Reference Files
1. Project documentation provided by user (complete technical specification and workflow)